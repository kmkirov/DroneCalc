

class CBattery
{
public:
private:
	float mf_weight;
	float mf_maxCapacity;
	float mf_maxDischargeC;
	float mf_wattHours;
};


